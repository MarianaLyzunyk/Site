from django.db import models

# Create your models here.f
from django.contrib.auth.models import AbstractUser
class User(AbstractUser):
	pass
